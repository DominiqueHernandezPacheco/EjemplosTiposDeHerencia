/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dominique.pokemoncontroladora;

/**
 *
 * @author SPARTAN PC
 */
public interface IPlanta {
  
    public void atacarParalizar();
    public void atacarDrenaje();
    public void atacarHojaAfilada();
    public void atacarLatigoCepa();

}
