/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dominique.pokemoncontroladora;

/**
 *
 * @author SPARTAN PC
 */
public interface IFuego {
   
   public void atacarPuñoFuego();
   
   public void atacarAscuas();
   
   public void atacarLazarLlamas();
}
